from core import *
from typing import List
import sympy as sp
import subprocess
import os

# Caminho absoluto para o diretório raiz do projeto (dois níveis acima de q2.py)
home = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

# Caminho para o arquivo tcc.tex
entrada = os.path.join(home, 'tcc.tex')

# Caminho para o diretório de saída (ex: ./out)
saida = os.path.join(home, 'out')

os.makedirs(saida, exist_ok=True)

# Comando de compilação
comando = [
    'xelatex',
    '-interaction=nonstopmode',
    f'-output-directory={saida}',
    entrada
]


def solve_q05(data: ResolvedData, beta: int) -> List[Step]:
    steps: List[Step] = []

    # Símbolos
    Pb, N, PCI = sp.symbols('Pb N PCI', positive=True, real=True)
    eta_th_f, eta_m, eta_v = sp.symbols('eta_th_f eta_m eta_v', positive=True, real=True)
    rho_ar = sp.Symbol('rho_ar', positive=True, real=True)
    AF = sp.Symbol('AF', positive=True, real=True)

    mdot_f = sp.Symbol('mdot_f', positive=True, real=True)
    V_ar = sp.Symbol('V_ar', positive=True, real=True)
    V_d = sp.Symbol('V_d', positive=True, real=True)

    # ETAPA 1: Consumo de combustível (kg/h)
    mdot_f_eq = sp.Eq(mdot_f, (Pb / (eta_th_f * PCI)) * 3600)
    mdot_f_value = float(mdot_f_eq.rhs.subs({
        Pb: data["Pb"],
        eta_th_f: data["eta_th_f"],
        PCI: data["PCI"]
    }).evalf())

    add_step(
        steps,
        "Consumo de combustível (kg/h)",
        "Usamos a definição da eficiência térmica ao freio para encontrar $\\dot{m}_f$: "
        "$\\dot{m}_f = \\frac{P_b}{\\eta_{th,f} \\cdot PCI} \\cdot 3600$. (kg/h)",
        expr=mdot_f_eq,
        value=mdot_f_value
    )

    # ETAPA 2: Vazão volumétrica de ar (m³/h)
    V_ar_eq = sp.Eq(V_ar, (AF * mdot_f) / rho_ar)
    V_ar_value = float(V_ar_eq.rhs.subs({
        AF: data["AF"],
        mdot_f: mdot_f_value,
        rho_ar: data["rho_ar"]
    }).evalf())

    add_step(
        steps,
        "Vazão de ar (m$^3$/h)",
        "Aplicando $\\dot{V}_{ar} = \\frac{AF \\cdot \\dot{m}_f}{\\rho_{ar}}$.",
        expr=V_ar_eq,
        value=V_ar_value
    )

    # ETAPA 3: Rotação (N em rpm) usando eficiência volumétrica

    # Motor 4T => f_ciclo = N / 120
    # eta_v = V_ar / (V_d * f_ciclo) => isolando N:
    # N = (V_ar / (eta_v * V_d)) * 120

    f_ciclo = N / 120
    N_eq_expr = (V_ar / (eta_v * V_d)) * 120
    N_eq = sp.Eq(N, N_eq_expr)

    N_value = float(N_eq_expr.subs({
        V_ar: V_ar_value,
        eta_v: data["eta_v"],
        V_d: data["V_d"]
    }).evalf())

    add_step(
        steps,
        "Rotação do motor (rpm)",
        "Usamos a fórmula da eficiência volumétrica em motores 4T: "
        "$\\eta_v = \\frac{\\dot{V}_{ar}}{V_d \\cdot N/120}$, isolando $N$.",
        expr=N_eq,
        value=N_value
    )

    return steps


raw_data_q05 = {
    "Pb": lambda beta, ctx: float(f"6{beta}000"),  # W
    "PCI": lambda beta, ctx: float(f"4{beta}000000"),  # J/kg
    "AF": 15,
    "eta_th_f": 0.35,
    "eta_m": 0.85,
    "eta_v": lambda beta, ctx: float(f"0.8{beta}"),
    "rho_ar": 1.181,  # kg/m³
    "V_d": 0.002  # 2.0 litros = 0.002 m³
}


def format_question_text_q05(data: ResolvedData) -> str:
    return f"""Determine a rotação do eixo de manivelas em rpm de um motor de ignição por centelha
a 4 tempos com \\textbf{{2,0 litros}} de cilindrada. O motor desenvolve uma potência ao freio de
\\textbf{{{data['Pb'] / 1000:.0f} kW}}, a razão ar/combustível é de {data["AF"]}:1;
a eficiência volumétrica é de \\textbf{{{data["eta_v"] * 100:.0f}\\%}}, eficiência térmica de 35\\%;
eficiência mecânica de 85\\%; poder calorífico inferior de \\textbf{{{data["PCI"] / 1e6:.0f} MJ/kg}} e
a massa específica do ar de admissão de {round(data["rho_ar"], 3)} kg/m³."""


if __name__ == "__main__":
    data, steps, beta = solve_problem(
        "Rotação a partir da eficiência volumétrica (β-adaptativo)",
        solve_q05, raw_data_q05, beta_value=4
    )

    section_tex = question_to_latex_section(
        q_number=5,
        problem_title="Rotação por Eficiência Volumétrica",
        given=data,
        steps=steps,
        question_text=format_question_text_q05(data)
    )

    with open("q05_section.tex", "w") as f:
        f.write(section_tex)

    print(f"✅ Q05 gerada (β={beta})")
    print(f"  N = {safe_float(steps[-1].value):.0f} rpm")


    processo = subprocess.run(comando, cwd=home, capture_output=True, text=True)

    # Mostra a saída da compilação
    # print('Saída:')
    # print(processo.stdout)
    #
    # print('\nErros:')
    # print(processo.stderr)


