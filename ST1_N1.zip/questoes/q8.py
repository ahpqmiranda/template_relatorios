from core import *
from typing import List
import sympy as sp
import subprocess
import os

# Caminho absoluto para o diretório raiz do projeto (dois níveis acima de q2.py)
home = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

# Caminho para o arquivo tcc.tex
entrada = os.path.join(home, 'tcc.tex')

# Caminho para o diretório de saída (ex: ./out)
saida = os.path.join(home, 'out')

os.makedirs(saida, exist_ok=True)

# Comando de compilação
comando = [
    'xelatex',
    '-interaction=nonstopmode',
    f'-output-directory={saida}',
    entrada
]

def solve_q08(data: ResolvedData, beta: int) -> List[Step]:
    steps: List[Step] = []

    # Símbolos
    Pb, Pi, Pf = sp.symbols("Pb Pi Pf", positive=True, real=True)
    eta_m, eta_th_i, eta_th_f = sp.symbols("eta_m eta_th_i eta_th_f", positive=True, real=True)
    mdot_f, mdot_ar, AF, PCI = sp.symbols("mdot_f mdot_ar AF PCI", positive=True, real=True)

    # ETAPA 1: Potência indicada
    Pi_eq = sp.Eq(Pi, Pb / eta_m)
    Pi_value = float(Pi_eq.rhs.subs({
        Pb: data["Pb"],
        eta_m: data["eta_m"]
    }).evalf())

    add_step(
        steps,
        "Potência indicada (kW)",
        "Aplicamos $P_i = \\frac{P_b}{\\eta_m}$ para obter a potência no ciclo indicado.",
        expr=Pi_eq,
        value=Pi_value
    )

    # ETAPA 2: Potência perdida por atrito
    Pf_eq = sp.Eq(Pf, Pi - Pb)
    Pf_value = float(Pf_eq.rhs.subs({
        Pi: Pi_value,
        Pb: data["Pb"]
    }).evalf())

    add_step(
        steps,
        "Potência perdida por atrito (kW)",
        "Calculada como $P_f = P_i - P_b$, diferença entre potências indicada e ao freio.",
        expr=Pf_eq,
        value=Pf_value
    )

    # ETAPA 3: Razão mássica ar/combustível
    AF_eq = sp.Eq(AF, mdot_ar / mdot_f)
    AF_value = float(AF_eq.rhs.subs({
        mdot_ar: data["mdot_ar"],
        mdot_f: data["mdot_f"]
    }).evalf())

    add_step(
        steps,
        "Razão mássica ar/combustível",
        "Razão entre massas consumidas: $AF = \\frac{\\dot{m}_{ar}}{\\dot{m}_f}$.",
        expr=AF_eq,
        value=AF_value
    )

    # ETAPA 4: Eficiência térmica indicada
    eta_th_i_eq = sp.Eq(eta_th_i, Pi * 3600 / (mdot_f * PCI))
    eta_th_i_value = float(eta_th_i_eq.rhs.subs({
        Pi: Pi_value,
        mdot_f: data["mdot_f"],
        PCI: data["PCI"]
    }).evalf())

    add_step(
        steps,
        "Eficiência térmica indicada",
        "Usamos $\\eta_{th,i} = \\frac{P_i \\cdot 3600}{\\dot{m}_f \\cdot PCI}$ para eficiência no ciclo indicado.",
        expr=eta_th_i_eq,
        value=eta_th_i_value
    )

    # ETAPA 5: Eficiência térmica efetiva
    eta_th_f_eq = sp.Eq(eta_th_f, Pb * 3600 / (mdot_f * PCI))
    eta_th_f_value = float(eta_th_f_eq.rhs.subs({
        Pb: data["Pb"],
        mdot_f: data["mdot_f"],
        PCI: data["PCI"]
    }).evalf())

    add_step(
        steps,
        "Eficiência térmica efetiva",
        "Calculada com $\\eta_{th,f} = \\frac{P_b \\cdot 3600}{\\dot{m}_f \\cdot PCI}$.",
        expr=eta_th_f_eq,
        value=eta_th_f_value
    )

    return steps


# === DADOS BETA ===
raw_data_q08 = {
    "Pb": lambda beta, ctx: float(f"4{beta}000"),  # W
    "eta_m": lambda beta, ctx: float(f"0.8{beta}"),
    "mdot_f": 160.0,  # kg/h
    "mdot_ar": 410 * 6,  # 410 kg/10min = 2460 kg/h
    "PCI": lambda beta, ctx: float(f"4{beta}000000"),  # J/kg
}


# === ENUNCIADO GERADO ===
def format_question_text_q08(data: ResolvedData) -> str:
    Pb_kw = float(data["Pb"]) / 1000
    PCI_mjkg = float(data["PCI"]) / 1e6
    eta_m_pct = float(data["eta_m"]) * 100

    return f"""Um motor de ignição por centelha produz uma potência ao freio de \\textbf{{{Pb_kw:.0f} kW}} com uma 
eficiência mecânica de \\textbf{{{eta_m_pct:.1f}\\%}}. Para manter essa potência, o motor consome \\textbf{{160 kg/h}} 
de combustível e \\textbf{{410 kg a cada 10 minutos}} de ar. Se o poder calorífico inferior (PCI) é de 
\\textbf{{{PCI_mjkg:.0f} MJ/kg}}, determinar:

\\begin{{enumerate}}
  \\item A potência indicada [kW]
  \\item A potência perdida por atrito [kW]
  \\item A razão mássica ar/combustível
  \\item A eficiência térmica indicada
  \\item A eficiência térmica efetiva
\\end{{enumerate}}"""


# === MAIN ===
if __name__ == "__main__":
    data, steps, beta = solve_problem(
        "Motor Otto - Potência, Razão AR/Comb e Eficiências",
        solve_q08, raw_data_q08, beta_value=4
    )

    section_tex = question_to_latex_section(
        q_number=8,
        problem_title="Potência, Razão AR/Comb, Eficiências",
        given=data,
        steps=steps,
        question_text=format_question_text_q08(data)
    )

    with open("q08_section.tex", "w") as f:
        f.write(section_tex)

    print(f"✅ Q08 gerada (β={beta})")
    print(f"  Pi     = {safe_float(steps[0].value):.2f} kW")
    print(f"  Pf     = {safe_float(steps[1].value):.2f} kW")
    print(f"  AF     = {safe_float(steps[2].value):.2f}")
    print(f"  η_th_i = {safe_float(steps[3].value)*100:.1f} %")
    print(f"  η_th_f = {safe_float(steps[4].value)*100:.1f} %")

    processo = subprocess.run(comando, cwd=home, capture_output=True, text=True)

    # Mostra a saída da compilação
    # print('Saída:')
    # print(processo.stdout)
    #
    # print('\nErros:')
    # print(processo.stderr)


