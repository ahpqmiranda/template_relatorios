from core import *
from typing import List
import sympy as sp
import subprocess
import os

# Caminho absoluto para o diretório raiz do projeto (dois níveis acima de q2.py)
home = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

# Caminho para o arquivo tcc.tex
entrada = os.path.join(home, 'tcc.tex')

# Caminho para o diretório de saída (ex: ./out)
saida = os.path.join(home, 'out')

os.makedirs(saida, exist_ok=True)

# Comando de compilação
comando = [
    'xelatex',
    '-interaction=nonstopmode',
    f'-output-directory={saida}',
    entrada
]


def solve_q06(data: ResolvedData, beta: int) -> List[Step]:
    steps: List[Step] = []

    # === SÍMBOLOS ===
    d, c = sp.symbols("d c", positive=True, real=True)
    Nc, N = sp.symbols("Nc N", positive=True, integer=True)  # número de cilindros, rotação
    rho_ar, rho_f = sp.symbols("rho_ar rho_f", positive=True)
    eta_v, eta_m, eta_g = sp.symbols("eta_v eta_m eta_g", positive=True)
    PCI = sp.Symbol("PCI", positive=True)
    Vdot_f = sp.Symbol("Vdot_f", positive=True)  # l/h
    mdot_f, mdot_ar = sp.symbols("mdot_f mdot_ar", positive=True)
    V_d = sp.Symbol("V_d", positive=True)
    Vdot_ar = sp.Symbol("Vdot_ar", positive=True)
    AF = sp.Symbol("AF", positive=True)

    P_e, P_b, P_i = sp.symbols("P_e P_b P_i", positive=True)
    Q_dot_in = sp.Symbol("Q_dot_in", positive=True)
    eta_th = sp.Symbol("eta_th", positive=True)
    SFC = sp.Symbol("SFC", positive=True)
    W_i, W_b = sp.symbols("W_i W_b", positive=True)

    # === ETAPA A: Razão ar-combustível ===

    # 1. Cilindrada unitária
    Vd_eq = sp.Eq(V_d, sp.pi * d**2 / 4 * c)
    Vd_value = float(Vd_eq.rhs.subs({
        d: data["d"],
        c: data["c"]
    }).evalf())
    add_step(steps, "Cilindrada unitária", "Cálculo de $V_d = \\frac{\\pi d^2}{4} c$", Vd_eq, Vd_value)

    # 2. Vazão volumétrica teórica
    f_ciclo = data["N"] / 120
    Vdot_ar_teor_expr = V_d * data["Nc"] * f_ciclo


    # 3. Vazão volumétrica real
    Vdot_ar_expr = eta_v * Vdot_ar_teor_expr
    Vdot_ar_value = float(Vdot_ar_expr.subs({
        V_d: Vd_value,
        eta_v: data["eta_v"]
    }).evalf())
    Vdot_ar_eq = sp.Eq(Vdot_ar, Vdot_ar_expr)
    add_step(steps, "Vazão volumétrica de ar", "Usamos $\\dot{V}_{ar} = \\eta_v V_d N_c f_{ciclo}$", Vdot_ar_eq, Vdot_ar_value)

    # 4. Vazão mássica de ar
    mdot_ar_expr = rho_ar * Vdot_ar * 3600
    mdot_ar_eq = sp.Eq(mdot_ar, mdot_ar_expr)
    mdot_ar_value = float(mdot_ar_expr.subs({
        Vdot_ar: Vdot_ar_value,
        rho_ar: data["rho_ar"]
    }).evalf())
    add_step(steps, "Vazão mássica de ar (kg/h)", "$\\dot{m}_{ar} = \\rho_{ar} \\cdot \\dot{V}_{ar} \\cdot 3600$", mdot_ar_eq, mdot_ar_value)

    # 5. Vazão mássica de combustível
    mdot_f_value = data["Vdot_f"] * data["rho_f"]
    mdot_f_eq = sp.Eq(mdot_f, Vdot_f * rho_f)
    add_step(steps, "Vazão mássica de combustível", "$\\dot{m}_f = \\dot{V}_f \\cdot \\rho_f$", mdot_f_eq, mdot_f_value)

    # 6. Razão A/F mássica
    AF_expr = mdot_ar / mdot_f
    AF_eq = sp.Eq(AF, AF_expr)
    AF_value = float(mdot_ar_value / mdot_f_value)
    add_step(steps, "Razão ar/combustível (mássica)", "$A/F = \\frac{\\dot{m}_{ar}}{\\dot{m}_f}$", AF_eq, AF_value)

    # === ETAPA B: Potência e trabalho ===

    # 7. Potência ao freio
    P_b_expr = P_e / eta_g
    P_b_eq = sp.Eq(P_b, P_b_expr)
    P_b_value = float(P_b_expr.subs({P_e: data["P_e"], eta_g: data["eta_g"]}))
    add_step(steps, "Potência no eixo (antes do gerador)", "$P_b = \\frac{P_e}{\\eta_g}$", P_b_eq, P_b_value)

    # 8. Potência indicada
    P_i_expr = P_b / eta_m
    P_i_eq = sp.Eq(P_i, P_i_expr)
    P_i_value = float(P_i_expr.subs({P_b: P_b_value, eta_m: data["eta_m"]}))
    add_step(steps, "Potência indicada", "$P_i = \\frac{P_b}{\\eta_m}$", P_i_eq, P_i_value)

    # 9. Trabalho por ciclo
    f_ciclo_expr = data["N"] / 120
    Wi_expr = P_i / (f_ciclo_expr * data["Nc"])
    Wi_eq = sp.Eq(W_i, Wi_expr)
    Wi_value = float(Wi_expr.subs({P_i: P_i_value}))
    add_step(steps, "Trabalho indicado por ciclo", "$W_i = \\frac{P_i}{f_{ciclo} \\cdot N_c}$", Wi_eq, Wi_value)

    Wb_expr = P_b / (f_ciclo_expr * data["Nc"])
    Wb_eq = sp.Eq(W_b, Wb_expr)
    Wb_value = float(Wb_expr.subs({P_b: P_b_value}))
    add_step(steps, "Trabalho efetivo por ciclo", "$W_b = \\frac{P_b}{f_{ciclo} \\cdot N_c}$", Wb_eq, Wb_value)

    # === ETAPA C: Eficiência e consumo específico ===

    Q_in_expr = mdot_f * PCI
    Q_in_eq = sp.Eq(Q_dot_in, Q_in_expr)
    Q_in_value = float(Q_in_expr.subs({mdot_f: mdot_f_value, PCI: data["PCI"]}))
    add_step(steps, "Potência térmica (W)", "$\\dot{Q}_{in} = \\dot{m}_f \\cdot PCI$", Q_in_eq, Q_in_value)

    eta_th_expr = P_b / Q_dot_in
    eta_th_eq = sp.Eq(eta_th, eta_th_expr)
    eta_th_value = float(P_b_value / Q_in_value)
    add_step(steps, "Eficiência térmica efetiva", "$\\eta_{th} = \\frac{P_b}{\\dot{Q}_{in}}$", eta_th_eq, eta_th_value)

    SFC_expr = (mdot_f * 1000) / P_b
    SFC_eq = sp.Eq(SFC, SFC_expr)
    SFC_value = float(SFC_expr.subs({mdot_f: mdot_f_value, P_b: P_b_value}))
    add_step(steps, "Consumo específico (g/kWh)", "$SFC = \\frac{\\dot{m}_f \\cdot 1000}{P_b}$", SFC_eq, SFC_value)

    return steps


# === DADOS ===

raw_data_q06 = {
    "P_e": lambda beta, ctx: float(f"2{beta}000"),  # W
    "N": lambda beta, ctx: float(f"2{beta}00"),  # rpm
    "Nc": 4,
    "d": 0.09,
    "c": 0.12,
    "rho_f": 0.8,
    "Vdot_f": 9,
    "PCI": lambda beta, ctx: float(f"4{beta}000000"),  # J/kg
    "eta_g": 0.82,
    "eta_m": 0.88,
    "eta_v": 0.90,
    "rho_ar": 1.181
}


def format_question_text_q06(data: ResolvedData) -> str:
    return f"""Um pequeno grupo gerador a diesel é utilizado para produzir potência elétrica de \\textbf{{{float(data['P_e']) / 1000:.0f} kW}}
a \\textbf{{{int(data['N'])} rpm}}. O motor tem 4 cilindros e opera em um ciclo de 4 tempos. 
O diâmetro dos cilindros é \\textbf{{90 mm}} e o curso do pistão é de \\textbf{{120 mm}}. 
O motor consome \\textbf{{9 l/h}} de óleo diesel com massa específica de \\textbf{{0,8 kg/l}} e 
poder calorífico inferior de \\textbf{{{float(data['PCI']) / 1e6:.0f} MJ/kg}}. 
A eficiência do gerador é de 82\\%, a eficiência mecânica do motor é de 88\\% 
e a eficiência volumétrica é de 90\\%. A massa específica do ar é de \\textbf{{1,181 kg/m³}}.

\\begin{{enumerate}}
\\item Calcule a razão mássica ar/combustível.
\\item Determine a potência indicada e os trabalhos por ciclo (indicado e efetivo).
\\item Determine a eficiência térmica efetiva e o consumo específico em g/kWh.
\\end{{enumerate}}
"""


# === MAIN ===
if __name__ == "__main__":
    data, steps, beta = solve_problem(
        "Grupo gerador diesel - rendimento global",
        solve_q06, raw_data_q06, beta_value=4
    )

    section_tex = question_to_latex_section(
        q_number=6,
        problem_title="Grupo Gerador Diesel",
        given=data,
        steps=steps,
        question_text=format_question_text_q06(data)
    )

    with open("q06_section.tex", "w") as f:
        f.write(section_tex)

    # print(f"✅ Q06 gerada (β={beta})")
    # print(f"  A/F = {safe_float(steps[5].value):.2f}")
    # print(f"  W_i = {safe_float(steps[9].value):.2f} J/ciclo")
    # print(f"  η_th = {safe_float(steps[11].value)*100:.1f} %")
    # print(f"  SFC = {safe_float(steps[12].value):.1f} g/kWh")

    processo = subprocess.run(comando, cwd=home, capture_output=True, text=True)

    # Mostra a saída da compilação
    # print('Saída:')
    # print(processo.stdout)
    #
    # print('\nErros:')
    # print(processo.stderr)


