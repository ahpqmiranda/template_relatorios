from core import *
from typing import List
import sympy as sp
import subprocess
import os

# Caminho absoluto para o diretório raiz do projeto (dois níveis acima de q2.py)
home = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

# Caminho para o arquivo tcc.tex
entrada = os.path.join(home, 'tcc.tex')

# Caminho para o diretório de saída (ex: ./out)
saida = os.path.join(home, 'out')

os.makedirs(saida, exist_ok=True)

# Comando de compilação
comando = [
    'xelatex',
    '-interaction=nonstopmode',
    f'-output-directory={saida}',
    entrada
]

def solve_q09(data: ResolvedData, beta: int) -> List[Step]:
    steps: List[Step] = []

    # Símbolos
    d, c = sp.symbols("d c", positive=True, real=True)
    V_d = sp.symbols("V_d", positive=True, real=True)
    Pb, Pi = sp.symbols("Pb Pi", positive=True, real=True)
    N = sp.Symbol("N", positive=True, real=True)
    eta_v, eta_th_f, eta_m = sp.symbols("eta_v eta_th_f eta_m", positive=True, real=True)
    AF, rho_ar, rho_f, PCI = sp.symbols("AF rho_ar rho_f PCI", positive=True, real=True)
    V_ar, mdot_f, m_f_Lph = sp.symbols("V_ar mdot_f m_f_Lph", positive=True, real=True)

    # === ETAPA 1: Cilindrada (cm³) ===
    Vd_eq = sp.Eq(V_d, sp.pi * d**2 / 4 * c)
    Vd_value_m3 = float(Vd_eq.rhs.subs({
        d: data["d"],
        c: data["c"]
    }).evalf())
    Vd_value_cm3 = Vd_value_m3 * 1e6  # m³ → cm³

    add_step(
        steps,
        "Cilindrada do motor (cm³)",
        "Usamos a fórmula $V_d = \\frac{\\pi \\cdot d^2}{4} \\cdot c$ e convertemos para cm³.",
        expr=Vd_eq,
        value=Vd_value_cm3
    )

    # === ETAPA 2: Vazão de ar (m³/s) ===
    f_ciclo = data["N"] / 60  # Motor 2 tempos: 1 ciclo por rotação
    V_ar_expr = eta_v * V_d * f_ciclo
    V_ar_value = float(V_ar_expr.subs({
        eta_v: data["eta_v"],
        V_d: Vd_value_m3,
        N: data["N"]
    }).evalf())

    V_ar_eq = sp.Eq(V_ar, V_ar_expr)
    add_step(
        steps,
        "Vazão volumétrica de ar admitido (m³/s)",
        "Para motor 2T: $f_{{ciclo}} = \\frac{{N}}{{60}}$. "
        "A vazão de ar é $\\dot{{V}}_{{ar}} = \\eta_v \\cdot V_d \\cdot f_{{ciclo}}$.",
        expr=V_ar_eq,
        value=V_ar_value
    )

    # === ETAPA 3: Vazão mássica de combustível (kg/s) ===
    mdot_f_expr = (rho_ar * V_ar) / AF
    mdot_f_eq = sp.Eq(mdot_f, mdot_f_expr)
    mdot_f_value = float(mdot_f_expr.subs({
        rho_ar: data["rho_ar"],
        V_ar: V_ar_value,
        AF: data["AF"]
    }).evalf())

    add_step(
        steps,
        "Vazão mássica de combustível (kg/s)",
        "A partir da razão ar/comb: $\\dot{{m}}_f = \\frac{{\\rho_{ar} \\cdot \\dot{V}_{ar}}}{{AF}}$.",
        expr=mdot_f_eq,
        value=mdot_f_value
    )

    # === ETAPA 4: PCI do combustível (MJ/kg) ===
    PCI_expr = Pb * 1000 / (eta_th_f * mdot_f * 3600)
    PCI_eq = sp.Eq(PCI, PCI_expr)
    PCI_value = float(PCI_expr.subs({
        Pb: data["Pi"],
        eta_th_f: data["eta_th_f"],
        mdot_f: mdot_f_value
    }).evalf()) / 1e6  # J/kg → MJ/kg

    add_step(
        steps,
        "Poder calorífico inferior (MJ/kg)",
        "Usamos $\\eta_{th,f} = \\frac{P_b}{\\dot{m}_f \\cdot PCI}$ e isolamos $PCI$.",
        expr=PCI_eq,
        value=PCI_value
    )

    # === ETAPA 5: Consumo em L/h ===
    m_f_Lph_expr = mdot_f * 3600 / rho_f
    m_f_Lph_eq = sp.Eq(m_f_Lph, m_f_Lph_expr)
    m_f_Lph_value = float(m_f_Lph_expr.subs({
        mdot_f: mdot_f_value,
        rho_f: data["rho_f"]
    }).evalf())

    add_step(
        steps,
        "Consumo de combustível (L/h)",
        "Convertendo de kg/s para L/h: $\\dot{{m}}_f = \\frac{{\\dot{{m}}_f \\cdot 3600}}{{\\rho_f}}$.",
        expr=m_f_Lph_eq,
        value=m_f_Lph_value
    )

    return steps


# === DADOS BETA ===
raw_data_q09 = {
    "d": 0.048,  # m
    "c": lambda beta, ctx: float(f"0.0{beta}"),  # m
    "N": lambda beta, ctx: float(f"5{beta}00"),  # rpm
    "Pi": 1.758,  # kW
    "AF": 10.8,  # razão ar/comb
    "eta_v": 0.65,
    "eta_th_f": 0.18,
    "eta_m": 0.70,
    "rho_ar": 1.2,  # kg/m³
    "rho_f": 0.76  # kg/L
}


# === ENUNCIADO GERADO ===
def format_question_text_q09(data: ResolvedData) -> str:
    d_mm = data["d"] * 1000
    c_mm = data["c"] * 1000
    N_rpm = int(data["N"])

    return f"""Um motor monocilíndrico de ignição por centelha, operando em ciclo de dois tempos, 
será utilizado para acionar uma bicicleta motorizada. O motor possui diâmetro do cilindro de 
\\textbf{{{d_mm:.0f} mm}} e curso do pistão de \\textbf{{{c_mm:.0f} mm}}. Em regime permanente de operação, 
à rotação de \\textbf{{{N_rpm} rpm}}, o motor desenvolve uma potência indicada de \\textbf{{1,758 kW}}, 
com razão ar/combustível igual a \\textbf{{10,8}}, eficiência volumétrica de \\textbf{{65\\%}}, eficiência térmica efetiva de 
\\textbf{{18\\%}} e eficiência mecânica de \\textbf{{70\\%}}. Se a massa específica do ar ambiente é 
\\textbf{{1,2 kg/m³}} e do combustível \\textbf{{0,76 kg/L}}, determinar:

\\begin{{enumerate}}
  \\item A cilindrada do motor, em cm³
  \\item O poder calorífico inferior (PCI), em MJ/kg
  \\item O consumo de combustível, em L/h
\\end{{enumerate}}"""


# === MAIN ===
if __name__ == "__main__":
    data, steps, beta = solve_problem(
        "Motor 2T - Cilindrada, PCI e Consumo",
        solve_q09, raw_data_q09, beta_value=4
    )

    section_tex = question_to_latex_section(
        q_number=9,
        problem_title="Cilindrada, PCI e Consumo",
        given=data,
        steps=steps,
        question_text=format_question_text_q09(data)
    )

    with open("q09_section.tex", "w") as f:
        f.write(section_tex)

    print(f"✅ Q09 gerada (β={beta})")
    print(f"  V_d   = {safe_float(steps[0].value):.2f} cm³")
    print(f"  PCI   = {safe_float(steps[3].value):.2f} MJ/kg")
    print(f"  Cons  = {safe_float(steps[4].value):.2f} L/h")


    processo = subprocess.run(comando, cwd=home, capture_output=True, text=True)

    # Mostra a saída da compilação
    # print('Saída:')
    # print(processo.stdout)
    #
    # print('\nErros:')
    # print(processo.stderr)


