from core import *
from typing import List
import sympy as sp
import subprocess
import os

import subprocess
import os

# Caminho absoluto para o diretório raiz do projeto (dois níveis acima de q2.py)
home = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

# Caminho para o arquivo tcc.tex
entrada = os.path.join(home, 'tcc.tex')

# Caminho para o diretório de saída (ex: ./out)
saida = os.path.join(home, 'out')

os.makedirs(saida, exist_ok=True)

# Comando de compilação
comando = [
    'xelatex',
    '-interaction=nonstopmode',
    f'-output-directory={saida}',
    entrada
]

def solve_q02(data: ResolvedData, beta: int) -> List[Step]:
    steps: List[Step] = []

    # Símbolos
    Pb, N, PCI, P_i = sp.symbols('Pb N PCI P_i', positive=True, real=True)
    eta_th_i, eta_m, eta_v = sp.symbols('eta_th_i eta_m eta_v', positive=True, real=True)
    Vf, V_ar, V_d = sp.symbols('Vf V_ar V_d', positive=True, real=True)
    AF = sp.Symbol('AF', positive=True, real=True)

    # ETAPA NÃO IDENTIFICADA

    power_i = sp.Eq(P_i, Pb / eta_m )
    power_i_value = float(power_i.rhs.subs({
        Pb: data["Pb"], eta_m: data["eta_m"]
    }).evalf())

    add_step(
        steps,
        "Potência Indicada (W)",
        "A potência indicada é dada por $P_i = \\frac{P_b}{\\eta_m}$. Determinamos para descobrir a potência indicada na saída do motor.",
        expr=power_i,
        value=round(power_i_value, 2)
    )

    # ETAPA 1: Vazão de combustível volumétrica (m³/s)
    Vf_eq = sp.Eq(Vf, Pb / (eta_th_i * PCI))
    Vf_value = float(Vf_eq.rhs.subs({
        Pb: data["Pb"],
        eta_th_i: data["eta_th_i"],
        PCI: data["PCI"]
    }).evalf())

    add_step(
        steps,
        "Vazão volumétrica de combustível (m$^3$/s)",
        "Usamos a definição de eficiência térmica indicada: "
        "$\\eta_{th,i} = \\frac{P_b}{\\dot{V}_f \\cdot PCI}$ "
        "para isolar $\\dot{V}_f$.",
        expr=Vf_eq,
        value=Vf_value
    )

    # ETAPA 2: Vazão de ar (m³/s)
    V_ar_eq = sp.Eq(V_ar, AF * Vf)
    V_ar_value = float(V_ar_eq.rhs.subs({
        AF: data["AF"],
        Vf: Vf_value
    }).evalf())

    add_step(
        steps,
        "Vazão de ar (m³/s)",
        "A partir da razão ar/combustível volumétrica, calculamos a vazão de ar: "
        "$\\dot{V}_{ar} = AF \\cdot \\dot{V}_f$.",
        expr=V_ar_eq,
        value=V_ar_value
    )

    # ETAPA 3: Cilindrada (em m³)
    f_ciclo = data["N"] / 120  # Motor 4 tempos

    Vd_eq = sp.Eq(V_d, V_ar / (eta_v * f_ciclo))
    Vd_value_m3 = float(Vd_eq.rhs.subs({
        V_ar: V_ar_value,
        eta_v: data["eta_v"],
        N: data["N"]
    }).evalf())

    Vd_value_L = Vd_value_m3 * 1000  # Conversão para litros

    add_step(
        steps,
        "Cilindrada total (L)",
        "Usamos a fórmula da eficiência volumétrica: "
        "$\\eta_v = \\frac{\\dot{V}_{ar}}{V_d \\cdot f_{ciclo}}$ "
        "e isolamos $V_d$. Convertido para litros ao final.",
        expr=Vd_eq,
        value=Vd_value_L
    )

    return steps

raw_data_q02 = {
    "Pb": lambda beta, ctx: float(f"2{beta}000"),  # W
    "N": lambda beta, ctx: float(f"60{beta}0"),  # rpm
    "PCI": lambda beta, ctx: float(f"1{beta}000000"),  # J/m³
    "AF": 8,  # ar/combustível (volumétrico)
    "eta_th_i": 0.33,  # 33%
    "eta_m": 0.90,
    "eta_v": 0.70,
}

def format_question_text_q02(data: ResolvedData) -> str:
    Pb_kw = float(data["Pb"]) / 1000
    N_rpm = int(float(data["N"]))
    PCI_mj = float(data["PCI"]) / 1e6

    return f"""Um motor monocilíndrico de ignição por centelha, de 4 tempos utiliza hidrogênio como
combustível produzindo \\textbf{{{Pb_kw:.0f} kW}} no eixo principal com rotação de {N_rpm} rpm.
A razão ar/combustível é de 8:1, razão ar/combustível e o PCI é \\textbf{{{PCI_mj:.0f} MJ/m³}}.
Se a eficiência volumétrica é de 70\\%, a eficiência térmica indicada é de 33\\% e a eficiência mecânica de 90\\%, 
calcule a cilindrada do motor em litros."""

if __name__ == "__main__":
    data, steps, beta = solve_problem(
        "Motor Otto 4T - Cilindrada por eficiência volumétrica",
        solve_q02, raw_data_q02, beta_value=4
    )

    section_tex = question_to_latex_section(
        q_number=2,
        problem_title="Cilindrada por Eficiência Volumétrica",
        given=data,
        steps=steps,
        question_text=format_question_text_q02(data)
    )

    with open("q02_section.tex", "w") as f:
        f.write(section_tex)

    print(f"✅ Q02 gerada (β={beta})")
    print(f"  V_d = {safe_float(steps[-1].value):.3f} litros")

    processo = subprocess.run(comando, cwd=home, capture_output=True, text=True)

    # Mostra a saída da compilação
    # print('Saída:')
    # print(processo.stdout)
    #
    # print('\nErros:')
    # print(processo.stderr)


