from core import *
from typing import List
import sympy as sp
import subprocess
import os

# Caminho absoluto para o diretório raiz do projeto (dois níveis acima de q2.py)
home = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

# Caminho para o arquivo tcc.tex
entrada = os.path.join(home, 'tcc.tex')

# Caminho para o diretório de saída (ex: ./out)
saida = os.path.join(home, 'out')

os.makedirs(saida, exist_ok=True)

# Comando de compilação
comando = [
    'xelatex',
    '-interaction=nonstopmode',
    f'-output-directory={saida}',
    entrada
]

from core import *
from typing import List
import sympy as sp


def solve_q10(data: ResolvedData, beta: int) -> List[Step]:
    steps: List[Step] = []

    # Símbolos
    T_f, T_c = sp.symbols('T_f T_c', positive=True, real=True)  # torque falha / correto
    n = sp.Symbol('n', positive=True, real=True)  # rotação
    eta_th_f, eta_th_c = sp.symbols('eta_th_f eta_th_c', positive=True, real=True)  # ef térmica
    eta_m = sp.Symbol('eta_m', positive=True, real=True)
    PCI = sp.Symbol('PCI', positive=True, real=True)
    rho_comb = sp.Symbol('rho_comb', positive=True, real=True)

    P_f, P_c = sp.symbols('P_f P_c', positive=True, real=True)  # Potência com falha / correta
    mf_f, mf_c = sp.symbols('mf_f mf_c', positive=True, real=True)  # consumo mássico

    # Potência ao freio: P = 2πNT/60
    P_f_eq = sp.Eq(P_f, 2 * sp.pi * T_f * n / 60)
    P_f_value = float(P_f_eq.rhs.subs({
        T_f: data["T_f"],
        n: data["n"]
    }).evalf())

    add_step(steps,
             "Potência efetiva com falha (kW)",
             "Potência calculada com torque reduzido usando $P = \\frac{2\\pi N T}{60}$.",
             expr=P_f_eq,
             value=P_f_value)

    P_c_eq = sp.Eq(P_c, 2 * sp.pi * T_c * n / 60)
    P_c_value = float(P_c_eq.rhs.subs({
        T_c: data["T_c"],
        n: data["n"]
    }).evalf())

    add_step(steps,
             "Potência efetiva após correção (kW)",
             "Potência calculada com torque total após correção da falha.",
             expr=P_c_eq,
             value=P_c_value)

    # Consumo mássico = η = P / (ṁf * PCI) → ṁf = P / (η * PCI)
    mf_f_eq = sp.Eq(mf_f, P_f / (eta_th_f * PCI))
    mf_f_value = float(mf_f_eq.rhs.subs({
        P_f: P_f_value,
        eta_th_f: data["eta_th_f_f"],
        PCI: data["PCI"]
    }).evalf())

    add_step(steps,
             "Consumo mássico com falha (kg/s)",
             "Aplicando a definição de eficiência térmica efetiva: "
             "$\\eta_{th} = \\frac{P}{\\dot{m}_f \\cdot PCI}$, isolando o consumo mássico.",
             expr=mf_f_eq,
             value=mf_f_value)

    mf_c_eq = sp.Eq(mf_c, P_c / (eta_th_c * PCI))
    mf_c_value = float(mf_c_eq.rhs.subs({
        P_c: P_c_value,
        eta_th_c: data["eta_th_f_c"],
        PCI: data["PCI"]
    }).evalf())

    add_step(steps,
             "Consumo mássico após correção (kg/s)",
             "Mesma equação, agora para condição corrigida.",
             expr=mf_c_eq,
             value=mf_c_value)

    # Consumo em L/h
    Lh_f = mf_f_value * 3600 / data["rho_comb"]
    Lh_c = mf_c_value * 3600 / data["rho_comb"]

    # Consumo específico (g/kWh)
    CEs_f = (mf_f_value * 3600 * 1000) / P_f_value
    CEs_c = (mf_c_value * 3600 * 1000) / P_c_value

    add_step(steps,
             "Consumo específico e volumétrico com falha e sem falha",
             "Calculamos o consumo específico como $CE = \\frac{\\dot{m}_f \\cdot 3600}{P}$ em g/kWh e volumétrico em L/h.",
             expr=None,
             value={"CE_f": CEs_f, "CE_c": CEs_c, "Lh_f": Lh_f, "Lh_c": Lh_c})

    # Eficiência térmica indicada: η_th_i = η_th_f / η_m
    eta_th_i_f = data["eta_th_f_f"] / data["eta_m"]
    eta_th_i_c = data["eta_th_f_c"] / data["eta_m"]

    # Potência indicada por cilindro = Pi / n_cilindros
    n_cil = 6
    Pi_f = P_f_value / data["eta_m"]
    Pi_c = P_c_value / data["eta_m"]
    Pi_unit_f = Pi_f / 5
    Pi_unit_c = Pi_c / 6

    add_step(steps,
             "Eficiência térmica indicada e potência por cilindro",
             "Usamos $\\eta_{th,i} = \\frac{\\eta_{th,f}}{\\eta_m}$ e potência indicada por cilindro.",
             expr=None,
             value={
                 "eta_th_i_f": eta_th_i_f,
                 "eta_th_i_c": eta_th_i_c,
                 "Pi_unit_f": Pi_unit_f,
                 "Pi_unit_c": Pi_unit_c
             })

    # Tempo total com tanque de 200 L
    t_f = 200 / Lh_f
    t_c = 200 / Lh_c

    add_step(steps,
             "Tempo total de operação (h)",
             "Com o tanque de 200 L, calculamos o tempo total operando com falha e com sistema corrigido.",
             expr=None,
             value={
                 "tempo_f": t_f,
                 "tempo_c": t_c
             })

    return steps


raw_data_q10 = {
    "T_f": 450,  # Nm
    "T_c": 604,  # Nm
    "n": lambda beta, ctx: float(f"2{beta}00"),  # rpm
    "eta_th_f_f": 0.28,
    "eta_th_f_c": 0.48,
    "eta_m": 0.85,
    "PCI": lambda beta, ctx: float(f"4{beta}000000"),  # J/kg
    "rho_comb": 0.85  # kg/L
}

def format_question_text_q10(data: ResolvedData) -> str:
    n_rpm = int(data["n"])
    PCI_mjkg = float(data["PCI"]) / 1e6

    return f"""
Um motor de ignição por compressão, com seis cilindros, opera em regime permanente utilizando óleo diesel como combustível, 
cuja massa específica é de \\textbf{{{data["rho_comb"]:.2f} kg/L}} e poder calorífico inferior (PCI) de \\textbf{{{PCI_mjkg:.0f} MJ/kg}}. 
Devido a uma falha técnica no sistema de injeção, ocorre a obstrução de um dos bicos injetores, impedindo o fornecimento de 
combustível em um dos cilindros. Nessas condições, o motor passa a operar com apenas cinco cilindros ativos, desenvolvendo um 
torque efetivo no eixo de \\textbf{{{data["T_f"]} N.m}}, com eficiência térmica efetiva de \\textbf{{{data["eta_th_f_f"] * 100:.0f}\\%}}.

Após a correção da falha, todos os cilindros voltam a operar normalmente, e o motor passa a desenvolver um torque efetivo de 
\\textbf{{{data["T_c"]} N.m}}, com eficiência térmica efetiva de \\textbf{{{data["eta_th_f_c"] * 100:.0f}\\%}}. 
Em ambas as condições de operação, o motor trabalha com uma rotação constante de \\textbf{{{n_rpm} rpm}}. 
Admita que a eficiência mecânica do motor permaneça constante e igual a 
\\textbf{{{data["eta_m"] * 100:.0f}\\%}}, tanto na condição com falha quanto após a correção da falha.

\\begin{{enumerate}}
\\item O consumo específico de combustível, em g/(kW·h), e o consumo de combustível consumido pelo motor, em L/h, nas duas condições de operação (com falha e após a correção da falha);
\\item A eficiência térmica indicada, em \\%, e a potência indicada unitária (por cilindro), em kW, nas duas condições de operação;
\\item Considerando que o tanque de combustível se encontra completamente cheio, com 200 L de óleo diesel, determine o tempo total de operação do motor, em horas, operando com a falha e operando após a correção da falha.
\\end{{enumerate}}
"""



if __name__ == "__main__":
    data, steps, beta = solve_problem(
        "Motor Diesel – Efeitos de falha na injeção",
        solve_q10, raw_data_q10, beta_value=4
    )

    section_tex = question_to_latex_section(
        q_number=10,
        problem_title="Motor Diesel – Falha na injeção",
        given=data,
        steps=steps,
        question_text=format_question_text_q10(data)
    )

    with open("q10_section.tex", "w") as f:
        f.write(section_tex)
    #
    # print(f"✅ Q10 gerada (β={beta})")
    # print(f"🔍 Tempo com falha: {safe_float(steps[-1].value['tempo_f']):.2f} h")
    # print(f"🔍 Tempo com correção: {safe_float(steps[-1].value['tempo_c']):.2f} h")
    # print(f"🔍 CE falha: {safe_float(steps[-2].value['CE_f']):.2f} g/kWh")
    # print(f"🔍 CE correta: {safe_float(steps[-2].value['CE_c']):.2f} g/kWh")


    processo = subprocess.run(comando, cwd=home, capture_output=True, text=True)

    # Mostra a saída da compilação
    # print('Saída:')
    # print(processo.stdout)
    #
    # print('\nErros:')
    # print(processo.stderr)


