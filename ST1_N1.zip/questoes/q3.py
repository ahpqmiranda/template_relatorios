from core import *
from typing import List
import sympy as sp
import subprocess
import os

import subprocess
import os

# Caminho absoluto para o diretório raiz do projeto (dois níveis acima de q2.py)
home = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

# Caminho para o arquivo tcc.tex
entrada = os.path.join(home, 'tcc.tex')

# Caminho para o diretório de saída (ex: ./out)
saida = os.path.join(home, 'out')

os.makedirs(saida, exist_ok=True)

# Comando de compilação
comando = [
    'xelatex',
    '-interaction=nonstopmode',
    f'-output-directory={saida}',
    entrada
]
def solve_q03(data: ResolvedData, beta: int) -> List[Step]:
    steps: List[Step] = []

    # Símbolos
    Pb, N, V_d, rho_ar = sp.symbols('Pb N V_d rho_ar', positive=True, real=True)
    eta_v, PCI, sfc = sp.symbols('eta_v PCI sfc', positive=True, real=True)
    pme, eta_th, AF = sp.symbols('pme eta_th AF', positive=True, real=True)
    mdot_f, mdot_ar = sp.symbols('mdot_f mdot_ar', positive=True, real=True)

    f_ciclo = data["N"] / 120

    # ETAPA A: Pressão média efetiva
    pme_eq = sp.Eq(pme, Pb / (V_d * f_ciclo))
    pme_value = float(pme_eq.rhs.subs({
        Pb: data["Pb"],
        V_d: data["V_d"],
    }).evalf())

    add_step(steps,
             "Pressão média efetiva (Pa)",
             "A pressão média efetiva é dada por $p_{me} = \\frac{P_b}{V_d \\cdot f_{ciclo}}$, "
             "com $f_{ciclo} = N/120$ para motor 4T.",
             expr=pme_eq,
             value=pme_value / 1e5  # Conversão para bar
             )

    # ETAPA B: Eficiência térmica efetiva
    mdot_f_eq = sp.Eq(mdot_f, (sfc * Pb) / 3600)
    mdot_f_value = float(mdot_f_eq.rhs.subs({
        sfc: data["sfc"],
        Pb: data["Pb"]
    }).evalf())

    eta_th_eq = sp.Eq(eta_th, Pb / (mdot_f * PCI))
    eta_th_value = float(eta_th_eq.rhs.subs({
        Pb: data["Pb"],
        mdot_f: mdot_f_value,
        PCI: data["PCI"]
    }).evalf())

    add_step(steps,
             "Eficiência térmica efetiva",
             "Primeiro, calculamos o consumo de combustível: "
             "$\\dot{m}_f = \\frac{sfc \\cdot P_b}{3600}$, "
             "depois usamos a definição $\\eta_{th} = \\frac{P_b}{\\dot{m}_f \\cdot PCI}$.",
             expr=eta_th_eq,
             value=eta_th_value
             )

    # ETAPA C: Razão ar-combustível
    V_adm = data["V_d"] * f_ciclo  # m³/s
    mdot_ar_eq = sp.Eq(mdot_ar, rho_ar * eta_v * V_adm)
    mdot_ar_value = float(mdot_ar_eq.rhs.subs({
        rho_ar: data["rho_ar"],
        eta_v: data["eta_v"]
    }).evalf())

    AF_eq = sp.Eq(AF, mdot_ar / mdot_f)
    AF_value = float(AF_eq.rhs.subs({
        mdot_ar: mdot_ar_value,
        mdot_f: mdot_f_value
    }).evalf())

    add_step(steps,
             "Razão mássica ar-combustível (AF)",
             "Calculamos a vazão mássica de ar via: "
             "$\\dot{m}_{ar} = \\rho_{ar} \\cdot \\eta_v \\cdot \\dot{V}_{adm}$, "
             "e então $AF = \\frac{\\dot{m}_{ar}}{\\dot{m}_f}$.",
             expr=AF_eq,
             value=AF_value
             )

    return steps


raw_data_q03 = {
    "Pb": lambda beta, ctx: float(f"9{beta}000"),  # W
    "N": lambda beta, ctx: float(f"3{beta}00"),  # rpm
    "V_d": 3.8e-3,  # m³
    "eta_v": 0.85,
    "sfc": 0.35,  # kg/kWh
    "PCI": lambda beta, ctx: float(f"4{beta}000000"),  # J/kg
    "rho_ar": 1.184
}

def format_question_text_q03(data: ResolvedData) -> str:
    return f"""Um motor de ignição por compressão com \\textbf{{3,8 litros}} de cilindrada, 4 tempos e 4 cilindros
gera uma potência de \\textbf{{{float(data["Pb"]) / 1000:.0f} kW}} a {int(data["N"])} rpm com eficiência volumétrica de 85\\%.
O consumo específico é de \\textbf{{350 g/kWh}} e o PCI do combustível é de \\textbf{{{float(data["PCI"]) / 1e6:.0f} MJ/kg}}.
Determine:
a) a pressão média efetiva [bar],
b) a eficiência térmica efetiva,
c) a razão mássica ar/combustível.

Considere: \\( \\rho_{{ar}} = 1.184 \\text{{ kg/m³}} \\), \\( T = 25^\\circ C \\), \\( p = 1 \\text{{ atm}} \\)."""

if __name__ == "__main__":
    data, steps, beta = solve_problem(
        "Motor Otto 4T - Cilindrada por eficiência volumétrica",
        solve_q03, raw_data_q03, beta_value=4
    )

    section_tex = question_to_latex_section(
        q_number=3,
        problem_title="Cilindrada por Eficiência Volumétrica",
        given=data,
        steps=steps,
        question_text=format_question_text_q03(data)
    )

    with open("q03_section.tex", "w") as f:
        f.write(section_tex)

    print(f"✅ Q03 gerada (β={beta})")
    print(f"  V_d = {safe_float(steps[-1].value):.3f} litros")

    processo = subprocess.run(comando, cwd=home, capture_output=True, text=True)

    # Mostra a saída da compilação
    # print('Saída:')
    # print(processo.stdout)
    #
    # print('\nErros:')
    # print(processo.stderr)


