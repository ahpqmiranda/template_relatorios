from core import *
from typing import List
import sympy as sp
import subprocess
import os

import subprocess
import os

# Caminho absoluto para o diretório raiz do projeto (dois níveis acima de q2.py)
home = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

# Caminho para o arquivo tcc.tex
entrada = os.path.join(home, 'tcc.tex')

# Caminho para o diretório de saída (ex: ./out)
saida = os.path.join(home, 'out')

os.makedirs(saida, exist_ok=True)

# Comando de compilação
comando = [
    'xelatex',
    '-interaction=nonstopmode',
    f'-output-directory={saida}',
    entrada
]
from core import *
from typing import List
import sympy as sp

def solve_q04(data: ResolvedData, beta: int) -> List[Step]:
    steps: List[Step] = []

    # Símbolos
    V_d, Nc, N = sp.symbols('V_d Nc N', positive=True, real=True)
    c = sp.Symbol('c', positive=True, real=True)  # curso (também é d)
    r = sp.Symbol('r', positive=True, real=True)  # razão compressão
    eta_v = sp.Symbol('eta_v', positive=True, real=True)
    rho_ar = sp.Symbol('rho_ar', positive=True, real=True)
    Vc, Vm, Up, mdot_ar = sp.symbols('V_c V_m U_p mdot_ar', positive=True, real=True)

    # ETAPA a: Curso do pistão (mm)
    c_eq = sp.Eq(c, sp.root((4 * V_d) / (Nc * sp.pi), 3))

    c_value_m = float(c_eq.rhs.subs({
        V_d: data["V_d"],
        Nc: data["Nc"]
    }).evalf())
    c_value_mm = c_value_m * 1000  # Conversão para mm

    add_step(
        steps,
        "Curso do pistão (mm)",
        "Para motor quadrado ($d = c$), usamos $V_d = n_c \\cdot \\frac{\\pi c^3}{4}$ e isolamos $c$.",
        expr=c_eq,
        value=c_value_mm
    )

    # ETAPA b: Velocidade média do pistão
    Up_eq = sp.Eq(Up, 2 * c * N / 60)
    Up_value = float(Up_eq.rhs.subs({
        c: c_value_m,
        N: data["N"]
    }).evalf())

    add_step(
        steps,
        "Velocidade média do pistão (m/s)",
        "A velocidade média é $U_p = \\frac{2 c N}{60}$.",
        expr=Up_eq,
        value=Up_value
    )

    # ETAPA c: Volume morto de 1 cilindro (litros)
    Vc_expr = V_d / Nc
    Vm_eq = sp.Eq(Vm, Vc / (r - 1))
    Vm_value = float(Vm_eq.rhs.subs({
        Vc: Vc_expr.subs({
            V_d: data["V_d"],
            Nc: data["Nc"]
        }),
        r: data["r"]
    }).evalf()) * 1000  # litros

    add_step(
        steps,
        "Volume morto de um cilindro (litros)",
        "Utilizamos $r = \\frac{V_c + V_m}{V_m}$ para isolar $V_m = \\frac{V_c}{r - 1}$.",
        expr=Vm_eq,
        value=Vm_value
    )

    # ETAPA d: Vazão mássica de ar admitido (kg/h)
    f_ciclo = data["N"] / 120
    Vadm = data["V_d"] * f_ciclo

    mdot_ar_eq = sp.Eq(mdot_ar, rho_ar * eta_v * Vadm)
    mdot_ar_value = float(mdot_ar_eq.rhs.subs({
        rho_ar: data["rho_ar"],
        eta_v: data["eta_v"]
    }).evalf()) * 3600  # kg/h

    add_step(
        steps,
        "Vazão mássica de ar (kg/h)",
        "Calculamos a vazão teórica $\\dot{V}_{adm} = V_d \\cdot f_{ciclo}$ e depois aplicamos: "
        "$\\dot{m}_{ar} = \\rho_{ar} \\cdot \\eta_v \\cdot \\dot{V}_{adm}$.",
        expr=mdot_ar_eq,
        value=mdot_ar_value
    )

    return steps


raw_data_q04 = {
    "V_d": 4e-3,  # m³
    "Nc": 6,
    "N": lambda beta, ctx: float(f"3{beta}00"),
    "r": 10,
    "eta_v": lambda beta, ctx: float(f"0.8{beta}"),
    "rho_ar": 1.184
}

def format_question_text_q04(data: ResolvedData) -> str:
    return f"""Um motor de combustão interna de 4 tempos, com \\textbf{{6 cilindros}} e cilindrada total de \\textbf{{4 litros}},
opera a {int(data["N"])} rpm com uma razão de compressão de 10:1 e eficiência volumétrica de {float(data["eta_v"]) * 100:.0f}\\%.
Sabendo que o motor é quadrado, determine:
a) o curso do pistão em mm,
b) a velocidade média do pistão em m/s,
c) o volume morto de um cilindro em litros,
d) a vazão mássica de ar admitido em kg/h.

Considere \\( \\rho_{{ar}} = 1.184 \\text{{ kg/m³}} \\)."""

if __name__ == "__main__":
    data, steps, beta = solve_problem(
        "Motor Otto 4T - Cilindrada por eficiência volumétrica",
        solve_q04, raw_data_q04, beta_value=4
    )

    section_tex = question_to_latex_section(
        q_number=4,
        problem_title="Cilindrada por Eficiência Volumétrica",
        given=data,
        steps=steps,
        question_text=format_question_text_q04(data)
    )

    with open("q04_section.tex", "w") as f:
        f.write(section_tex)

    print(f"✅ Q04 gerada (β={beta})")
    print(f"  V_d = {safe_float(steps[-1].value):.3f} litros")

    processo = subprocess.run(comando, cwd=home, capture_output=True, text=True)

    # Mostra a saída da compilação
    # print('Saída:')
    # print(processo.stdout)
    #
    # print('\nErros:')
    # print(processo.stderr)


